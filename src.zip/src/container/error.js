function Error() {
    return(
        <>
        <h1>Error page</h1>
        </>
    )
    
}

export default Error;