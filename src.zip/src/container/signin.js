function Signin() {
    return(
        <>
        <h1>Signin page</h1>
        </>
    )
    
}

export default Signin;