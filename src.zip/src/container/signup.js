function Signup() {
    return(
        <>
        <h1>Signup page</h1>
        </>
    )
    
}

export default Signup;