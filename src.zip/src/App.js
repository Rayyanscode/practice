import logo from './logo.svg';
import './App.css';
import Approuter from './config/router';

function App() {
  return (
    <div className="App">
      <Approuter />
         </div>
  );
}

export default App;
