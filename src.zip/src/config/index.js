import Home from "../container/home";
import Signin from "../container/signin";
import Signup from "../container/signup";
import Contact from "../container/contact";
import Error from "../container/error";

export {Home,Signin,Signup,Contact,Error}