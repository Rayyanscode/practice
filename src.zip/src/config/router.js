import React from "react";
import {
  BrowserRouter as Router,
  Switch,
  Routes,
  Route,
  Link
} from "react-router-dom";
import { Home,Contact, Signin, Signup,Error } from "./index";

export default function Approuter() {
  return (
    <>

    <Router>
        <Routes>
            <Route path='/' element={<Home/>}/>
            <Route path='/contact' element={<Contact/>}/>
            <Route path='/signin' element={<Signin/>}/>
            <Route path='/signup' element={<Signup/>}/>
            <Route path='*' element={<Error/>}/>
        </Routes>
    </Router>




    </>          
  );
}